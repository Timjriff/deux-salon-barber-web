import { spawn } from "node:child_process";

const command = process.argv[2];

if (!["dev", "build", "start"].includes(command)) {
  console.error("Expected one of: dev, build, start");
  process.exit(1);
}

const bin = process.platform === "win32" ? "vinext.cmd" : "vinext";
const child = spawn(bin, [command], {
  stdio: "inherit",
  shell: process.platform === "win32",
  env: {
    ...process.env,
    WRANGLER_LOG_PATH: ".wrangler/wrangler.log",
  },
});

child.on("exit", (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
    return;
  }
  process.exit(code ?? 1);
});
