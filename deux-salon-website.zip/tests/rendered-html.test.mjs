import assert from "node:assert/strict";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request("http://localhost/", {
      headers: {
        accept: "text/html",
        host: "localhost",
      },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );
}

test("server-renders the complete Deux Salon & Barber page", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /Deux Salon &amp; Barber/);
  assert.match(html, /Your style/);
  assert.match(html, /Precision Cuts/);
  assert.match(html, /Color &amp; Dimension/);
  assert.match(html, /3232 E Broadway/);
  assert.match(html, /562-433-3588/);
  assert.match(html, /tel:\+15624333588/);
  assert.match(html, /google\.com\/maps\/dir/);
  assert.doesNotMatch(html, /codex-preview|SkeletonPreview|Starter Project/);
});

test("renders accessible page landmarks and metadata", async () => {
  const response = await render();
  const html = await response.text();

  assert.match(html, /<main>/);
  assert.match(html, /<nav aria-label="Main navigation">/);
  assert.match(html, /application\/ld\+json/);
  assert.match(html, /og:image/);
  assert.match(html, /summary_large_image/);
});
