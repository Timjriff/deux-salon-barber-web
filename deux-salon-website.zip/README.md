# Deux Salon & Barber

A polished, responsive single-page website for Deux Salon & Barber in Long
Beach, California.

## Run locally

Requirements: Node.js 22.13 or newer.

```bash
npm install
npm run dev
```

Open `http://localhost:3000` in a browser.

## Production build

```bash
npm run build
npm run start
```

## Main files

- `app/page.tsx` — page content and business details
- `app/globals.css` — visual design and responsive layout
- `app/layout.tsx` — search and social-sharing metadata
- `public/og.png` — social-sharing artwork

The site uses no external image, font, analytics, or booking dependencies.
Booking buttons call `562-433-3588`, and directions open Google Maps for
3232 E Broadway, Long Beach, CA 90803.
