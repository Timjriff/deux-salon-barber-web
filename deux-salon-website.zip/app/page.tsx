import type { Metadata } from "next";

const phoneDisplay = "562-433-3588";
const phoneHref = "tel:+15624333588";
const address = "3232 E Broadway, Long Beach, CA 90803";
const directionsHref =
  "https://www.google.com/maps/dir/?api=1&destination=3232+E+Broadway%2C+Long+Beach%2C+CA+90803";

export const metadata: Metadata = {
  title: "Deux Salon & Barber | Long Beach, CA",
  description:
    "Elevated cuts, color, grooming, and styling at Deux Salon & Barber on East Broadway in Long Beach.",
};

const services = [
  {
    number: "01",
    title: "Precision Cuts",
    description:
      "Thoughtful cuts tailored to your texture, routine, and personal style.",
    detail: "Women · Men · All textures",
  },
  {
    number: "02",
    title: "Color & Dimension",
    description:
      "Lived-in color, dimensional highlights, rich glosses, and seamless gray blending.",
    detail: "Color · Highlights · Gloss",
  },
  {
    number: "03",
    title: "Barbering",
    description:
      "Clean fades, classic scissor work, lineups, and beard detailing with a modern finish.",
    detail: "Fades · Shaves · Beard care",
  },
  {
    number: "04",
    title: "Style & Finish",
    description:
      "Polished blowouts and occasion styling designed to move beautifully and last.",
    detail: "Blowouts · Events · Finishing",
  },
];

export default function Home() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "HairSalon",
    name: "Deux Salon & Barber",
    telephone: "+1-562-433-3588",
    address: {
      "@type": "PostalAddress",
      streetAddress: "3232 E Broadway",
      addressLocality: "Long Beach",
      addressRegion: "CA",
      postalCode: "90803",
      addressCountry: "US",
    },
  };

  return (
    <main>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <header className="site-header">
        <a className="brand" href="#top" aria-label="Deux Salon & Barber home">
          <span className="brand-main">DEUX</span>
          <span className="brand-sub">Salon &amp; Barber</span>
        </a>
        <nav aria-label="Main navigation">
          <a href="#services">Services</a>
          <a href="#about">Our salon</a>
          <a href="#visit">Visit</a>
        </nav>
        <a className="header-cta" href={phoneHref}>
          Book an appointment
        </a>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">Long Beach · California</p>
          <h1>
            Your style,
            <br />
            <em>refined.</em>
          </h1>
          <p className="hero-intro">
            Elevated salon craft and modern barbering, brought together in one
            welcoming neighborhood space.
          </p>
          <div className="hero-actions">
            <a className="button button-dark" href={phoneHref}>
              Call to book <span aria-hidden="true">↗</span>
            </a>
            <a className="text-link" href="#services">
              Explore services <span aria-hidden="true">↓</span>
            </a>
          </div>
          <div className="hero-location">
            <span className="location-mark" aria-hidden="true" />
            <p>
              <strong>Belmont Heights</strong>
              <br />
              3232 E Broadway, Long Beach
            </p>
          </div>
        </div>

        <div className="hero-visual" aria-label="A refined salon interior">
          <div className="visual-monogram">D</div>
          <div className="arch">
            <div className="mirror">
              <span className="mirror-glint" />
            </div>
            <div className="chair">
              <span className="chair-back" />
              <span className="chair-seat" />
              <span className="chair-stem" />
              <span className="chair-base" />
            </div>
            <div className="side-table">
              <span />
            </div>
          </div>
          <p className="visual-caption">
            <span>Deux</span>
            Beauty and craft in equal measure.
          </p>
        </div>
      </section>

      <section className="marquee" aria-label="Salon specialties">
        <div>
          <span>Cut</span><i>✦</i><span>Color</span><i>✦</i>
          <span>Barber</span><i>✦</i><span>Style</span><i>✦</i>
          <span>Cut</span><i>✦</i><span>Color</span>
        </div>
      </section>

      <section className="services section" id="services">
        <div className="section-heading">
          <p className="eyebrow">What we do</p>
          <h2>Personal style. Expert hands.</h2>
          <p>
            Every appointment begins with a conversation and ends with a look
            that feels unmistakably yours.
          </p>
        </div>
        <div className="service-grid">
          {services.map((service) => (
            <article className="service-card" key={service.number}>
              <div className="service-top">
                <span>{service.number}</span>
                <span aria-hidden="true">↗</span>
              </div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <small>{service.detail}</small>
            </article>
          ))}
        </div>
        <p className="service-note">
          Service pricing varies by stylist, time, and hair goals. Call for a
          consultation and personalized quote.
        </p>
      </section>

      <section className="about section" id="about">
        <div className="about-art" aria-hidden="true">
          <span className="about-number">02</span>
          <span className="about-word">DEUX</span>
          <div className="about-line" />
        </div>
        <div className="about-copy">
          <p className="eyebrow">The Deux approach</p>
          <h2>One chair. One conversation. One look that’s truly yours.</h2>
          <p>
            Deux Salon &amp; Barber is where considered technique meets easy,
            personal service. We believe the best hair feels like you—only more
            polished, more expressive, and easier to live in.
          </p>
          <p>
            From precise barbering to dimensional color, our work is grounded
            in detail and shaped around the person in the chair.
          </p>
          <a className="text-link" href={phoneHref}>
            Meet us at your next appointment <span aria-hidden="true">↗</span>
          </a>
        </div>
      </section>

      <section className="testimonial">
        <p className="quote-mark">“</p>
        <blockquote>
          Great hair should turn heads—
          <br />
          and still feel completely like you.
        </blockquote>
        <p>THE DEUX PHILOSOPHY</p>
      </section>

      <section className="visit section" id="visit">
        <div className="visit-heading">
          <p className="eyebrow">Come see us</p>
          <h2>Ready for your next look?</h2>
          <p>
            Call to reserve your appointment. We’ll help match you with the
            right service and timing.
          </p>
          <a className="button button-light" href={phoneHref}>
            {phoneDisplay} <span aria-hidden="true">↗</span>
          </a>
        </div>
        <div className="visit-details">
          <div>
            <p className="detail-label">Find us</p>
            <address>
              3232 E Broadway
              <br />
              Long Beach, CA 90803
            </address>
            <a href={directionsHref} target="_blank" rel="noreferrer">
              Get directions ↗
            </a>
          </div>
          <div>
            <p className="detail-label">Hours</p>
            <p>
              Appointments available
              <br />
              Call for current availability
            </p>
            <a href={phoneHref}>Call the salon ↗</a>
          </div>
        </div>
      </section>

      <footer>
        <a className="footer-brand" href="#top">
          DEUX
          <span>Salon &amp; Barber</span>
        </a>
        <p>3232 E Broadway · Long Beach, CA 90803</p>
        <p>
          <a href={phoneHref}>{phoneDisplay}</a>
        </p>
        <p className="copyright">
          © {new Date().getFullYear()} Deux Salon &amp; Barber
        </p>
      </footer>

      <div className="mobile-booking">
        <a href={phoneHref}>
          <span>Book by phone</span>
          <strong>{phoneDisplay}</strong>
        </a>
      </div>
    </main>
  );
}
