import type { Metadata, Viewport } from "next";
import { headers } from "next/headers";
import "./globals.css";

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host = requestHeaders.get("host") ?? "localhost:3000";
  const protocol =
    requestHeaders.get("x-forwarded-proto") ??
    (host.startsWith("localhost") ? "http" : "https");
  const baseUrl = new URL(`${protocol}://${host}`);

  return {
    title: {
      default: "Deux Salon & Barber",
      template: "%s | Deux Salon & Barber",
    },
    description:
      "Modern hair salon and barbershop in Long Beach, California. Call 562-433-3588 to book.",
    metadataBase: baseUrl,
    openGraph: {
      title: "Deux Salon & Barber",
      description:
        "Your style, refined. Salon craft and modern barbering in Long Beach.",
      type: "website",
      locale: "en_US",
      images: [
        {
          url: new URL("/og.png", baseUrl).toString(),
          width: 1672,
          height: 941,
          alt: "Deux Salon & Barber — Your style, refined.",
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: "Deux Salon & Barber",
      description:
        "Your style, refined. Salon craft and modern barbering in Long Beach.",
      images: [new URL("/og.png", baseUrl).toString()],
    },
  };
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#292923",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
